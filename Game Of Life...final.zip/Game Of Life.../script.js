// let grassArr = [];
// let grassEaterArr = [];
// let predatorArr = [];
// let PosionedGrassArr = [];
// let vochxarArr = [];
// let matrix = [];



// var socket = io();

// function kill() {
//     socket.emit("kill")
// }
// function addGrass() {
//     socket.emit("add grass")
// }
// function addGrassEater() {
//     socket.emit("add grassEater")
// }


// function matrixGen(n, gr, grEat, predator, posion) {
//   for (let x = 0; x < n; x++) {
//     matrix[x] = [];
//     for (let y = 0; y < n; y++) {
//       matrix[x][y] = 0;
//     }
//   }

//   for (let i = 0; i < gr; i++) {
//     let x = Math.floor(Math.random() * n);
//     let y = Math.floor(Math.random() * n);

//     if (matrix[x][y] == 0) {
//       matrix[x][y] = 1;
//     } else {
//       i--;
//     }
//   }

//   for (let i = 0; i < grEat; i++) {
//     let x = Math.floor(Math.random() * n);////////////////////////////////////////////////////////////////////////////////////////////
//     let y = Math.floor(Math.random() * n);

//     if (matrix[x][y] == 0) {
//       matrix[x][y] = 2;
//     } else {
//       i--;
//     }
//   }
//   for (let i = 0; i < predator; i++) {
//     let x = Math.floor(Math.random() * n);
//     let y = Math.floor(Math.random() * n);

//     if (matrix[x][y] == 0) {
//       matrix[x][y] = 3;
//     } else {
//       i--;
//     }
//   }
//   for (let i = 0; i < posion; i++) {
//     let x = Math.floor(Math.random() * n);
//     let y = Math.floor(Math.random() * n);

//     if (matrix[x][y] == 0) {
//       matrix[x][y] = 4;
//     } else {
//       i--;
//     }
//   }

//   return n;
// }
// var n;
// matrixGen(25, 10, 30, 3, 2);
// function rand(arr) {
//   return arr[Math.floor(Math.random() * arr.length)];
// }

// let side = 25;
function rand(arr) {
  return arr[Math.floor(Math.random() * arr.length)]
}

var socket = io()
var side = 10
function setup() {
  createCanvas(50 * side, 50 * side);
  frameRate(120);

  background("#2e4057");
  // const mard = new Mard(0, 0);

}

function drw(matrix) {
  for (var x = 0; x < matrix.length; x++) {
    for (var y = 0; y < matrix[x].length; y++) {
      if (matrix[x][y] == 0) {
        fill("#acacac");
      } else if (matrix[x][y] == 1) {
        fill("green");
      } else if (matrix[x][y] == 2) {
        fill("yellow");
      } else if (matrix[x][y] == 3) {
        fill("red");
      } else if (matrix[x][y] == 4) {
        fill("brown");
      } else if (matrix[x][y] == 5) {
        fill("black");
      } else if (matrix[x][y] == 9) {///////////////////////////////////////////<-(9)?
        fill("black");
      }
      ellipse(y * side + side / 2, x * side + side / 2, side, side);
    }
  }
}
socket.on("send matrix",drw)